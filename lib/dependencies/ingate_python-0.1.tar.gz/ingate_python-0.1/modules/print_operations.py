import json
from escpos.printer import Usb
from datetime import datetime
import PIL.Image

def print_struk(barcode_data):
    def load_config(file_path='config.json'):
        with open(file_path, 'r') as file:
            config = json.load(file)
        return config

    # Load configuration within the function
    config = load_config()

    settings = config['printer_settings']
    try:
        # Create USB printer object
        printer = Usb(settings['vendor_id'], settings['product_id'], timeout=0,
                      in_ep=settings['endpoint_in'], out_ep=settings['endpoint_out'])

        # Print company header
        printer.set(align='center')
        printer.text(f"{config['nama_perusahaan']}\n{config['lokasi_parkir']}\n\n")
        
        # Print entrance ID and timestamp
        printer.set(align='left')
        text = f"Entrance ID: {config['id_pintu_Masuk']}\n{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        printer.text(text)
        
        # Print barcode image
        try:
            barcode_image = PIL.Image.open(barcode_data)
            printer.image(barcode_image)
        except Exception as e:
            print(f"Error loading or printing barcode: {e}")
        
        # Cut the paper
        printer.cut()
    except Exception as e:
        print(f"Error with the printer: {e}")
    finally:
        # Ensure the printer connection is closed properly
        if 'printer' in locals():
            printer.close()


