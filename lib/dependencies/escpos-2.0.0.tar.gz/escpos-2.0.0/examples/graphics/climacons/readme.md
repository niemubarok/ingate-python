# Climacons by Adam Whitcroft

75 climatically categorised pictographs for web and UI design by [@adamwhitcroft](https://www.twitter.com/#!/adamwhitcroft).

Visit the [Climacons](https://adamwhitcroft.com/climacons/) website for more information.

Visit [Adam Whitcroft on GitHub](https://github.com/AdamWhitcroft)

## License
You are free to use any of the Climacons Icons (the "icons") in any personal or commercial work without obligation of payment (monetary or otherwise) or attribution, however a credit for the work would be appreciated. **Do not** redistribute or sell and **do not** claim creative credit. Intellectual property rights are not transferred with the download of the icons.
