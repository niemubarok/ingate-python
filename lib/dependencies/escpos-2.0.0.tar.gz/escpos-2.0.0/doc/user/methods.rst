*******
Methods
*******
:Last Reviewed: 2017-01-25

Escpos class
------------

The core part of this libraries API is the Escpos class.
You use it by instantiating a  :doc:`printer <printers>` which is a child of Escpos.
The following methods are available:

.. autoclass:: escpos.escpos.Escpos
    :members:
    :member-order: bysource
    :noindex:

