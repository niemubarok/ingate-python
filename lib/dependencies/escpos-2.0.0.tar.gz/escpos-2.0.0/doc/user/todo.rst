****
TODO
****

Open points and issues of the project are tracked in the GitHub issues.
Some annotations still remain in the code and should be moved over time
into the issue tracker.

Todos in the codebase
~~~~~~~~~~~~~~~~~~~~~

.. todolist::


