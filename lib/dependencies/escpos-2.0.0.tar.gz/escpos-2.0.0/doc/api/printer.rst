Printer implementations
-----------------------
Module :py:mod:`escpos.printer`

.. automodule:: escpos.printer
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
