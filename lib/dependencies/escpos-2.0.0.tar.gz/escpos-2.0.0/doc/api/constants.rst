Constants
---------
Module :py:mod:`escpos.constants`

.. automodule:: escpos.constants
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
