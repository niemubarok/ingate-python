Katakana
--------
Module :py:mod:`escpos.katakana`

.. automodule:: escpos.katakana
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource