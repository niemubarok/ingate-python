Codepages
---------
Module :py:mod:`escpos.codepages`

.. automodule:: escpos.codepages
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource