Exceptions
----------
Module :py:mod:`escpos.exceptions`

.. automodule:: escpos.exceptions
    :members:
    :inherited-members:
    :show-inheritance:
    :member-order: bysource