Config
------
Module :py:mod:`escpos.config`

.. automodule:: escpos.config
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
