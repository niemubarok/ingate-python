Capabilities
------------
Module :py:mod:`escpos.capabilities`

.. automodule:: escpos.capabilities
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource