Magic Encode
------------
Module :py:mod:`escpos.magicencode`

.. automodule:: escpos.magicencode
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource